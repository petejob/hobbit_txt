# hobbit_txt

[hobbit_txt](https://twitter.com/hobbit_txt) is a twitter bot posting quotes from The Hobbit and The Lord Of The Rings series.

Written in node and uses npm package [twit](https://www.npmjs.com/package/twit) for calls to the twitter api.

Source text is from archive.org

- [The Hobbit](https://archive.org/details/TheHobbitByJ.R.RTolkien)
- [The Lord Of The Rings](https://archive.org/details/TheLordOfTheRing1TheFellowshipOfTheRing)

_Here is our noble cousin! Make way for Frodo, Lord of the Ring!_

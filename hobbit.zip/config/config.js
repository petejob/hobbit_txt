module.exports = {
  api_key: "elPCYvPtImUCPLppCr6TFBE0r",
  api_secret: "CwR5p16Y6La6p4NCAI8nzre1klMBA8mUKEbSyc8a3nE5VBA4ra",
  access_token: "1082632087176470528-guMYE7pidSiOAPPG2M02oZsXAo2s4i",
  access_secret: "UpBPKgIzIMtH3Fetf21UNwLrAxqpPyKfbH97IFmsYjqUj"
};
